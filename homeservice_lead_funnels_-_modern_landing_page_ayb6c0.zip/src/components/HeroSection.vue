<script setup lang="ts">
</script>

<template>
  <section class="hero">
    <div class="glow glow-primary" style="top: -100px; left: -100px;"></div>
    <div class="glow glow-secondary" style="bottom: -100px; right: -100px;"></div>
    
    <div class="container">
      <div class="hero-content">
        <h1>Transform Your Home Service Business With High-Converting Funnels</h1>
        <p class="subtitle">We build lead generation machines that work 24/7 through ads, SEO, and email marketing</p>
        <a href="#cta" class="btn btn-primary">Book a Free Strategy Call</a>
      </div>
      
      <div class="hero-image">
        <div class="dashboard-animation">
          <div class="screen"></div>
          <div class="data-points">
            <div v-for="i in 8" :key="i" class="data-point"></div>
          </div>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.hero {
  min-height: 100vh;
  display: flex;
  align-items: center;
  position: relative;
  overflow: hidden;
  padding-top: 80px;
}

.hero-content {
  max-width: 600px;
  margin-bottom: 60px;
}

.hero h1 {
  font-size: 3.5rem;
  font-weight: 700;
  line-height: 1.2;
  margin-bottom: 1.5rem;
  background: linear-gradient(90deg, white, rgba(255, 255, 255, 0.9));
  -webkit-background-clip: text;
  background-clip: text;
  color: transparent;
}

.hero .subtitle {
  font-size: 1.2rem;
  color: rgba(255, 255, 255, 0.8);
  margin-bottom: 2.5rem;
  line-height: 1.6;
}

.hero-image {
  position: absolute;
  right: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 50%;
  max-width: 700px;
}

.dashboard-animation {
  width: 100%;
  aspect-ratio: 16/9;
  background: rgba(20, 20, 30, 0.5);
  border-radius: 20px;
  border: 1px solid rgba(255, 255, 255, 0.1);
  backdrop-filter: blur(10px);
  position: relative;
  overflow: hidden;
  box-shadow: 0 20px 50px rgba(0, 0, 0, 0.3);
  animation: float 6s ease-in-out infinite;
}

.screen {
  position: absolute;
  inset: 0;
  background: linear-gradient(135deg, rgba(108, 71, 255, 0.1), rgba(0, 240, 255, 0.1));
}

.data-points {
  position: absolute;
  inset: 0;
}

.data-point {
  position: absolute;
  width: 8px;
  height: 8px;
  border-radius: 50%;
  background: var(--primary);
  box-shadow: 0 0 10px var(--primary);
  animation: pulse 2s infinite;
}

.data-point:nth-child(1) { top: 20%; left: 15%; animation-delay: 0s; }
.data-point:nth-child(2) { top: 40%; left: 25%; animation-delay: 0.5s; }
.data-point:nth-child(3) { top: 60%; left: 35%; animation-delay: 1s; }
.data-point:nth-child(4) { top: 30%; left: 55%; animation-delay: 1.5s; }
.data-point:nth-child(5) { top: 50%; left: 65%; animation-delay: 0.2s; }
.data-point:nth-child(6) { top: 70%; left: 75%; animation-delay: 0.7s; }
.data-point:nth-child(7) { top: 25%; left: 85%; animation-delay: 1.2s; }
.data-point:nth-child(8) { top: 45%; left: 45%; animation-delay: 1.7s; }

@keyframes pulse {
  0% { transform: scale(1); opacity: 1; }
  50% { transform: scale(1.5); opacity: 0.7; }
  100% { transform: scale(1); opacity: 1; }
}

@media (max-width: 1024px) {
  .hero h1 {
    font-size: 2.5rem;
  }
  
  .hero-image {
    position: relative;
    width: 100%;
    max-width: 100%;
    transform: none;
    margin-top: 50px;
  }
  
  .hero-content {
    max-width: 100%;
  }
}
</style>
