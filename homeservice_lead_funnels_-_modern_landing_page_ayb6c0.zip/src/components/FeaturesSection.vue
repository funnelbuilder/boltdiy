<script setup lang="ts">
const features = [
  {
    title: "Ad-Optimized Funnels",
    description: "Funnels designed to maximize conversions from your paid ads with proven psychological triggers.",
    icon: "📈"
  },
  {
    title: "SEO-First Approach",
    description: "Built to rank organically with proper structure, speed, and content optimization.",
    icon: "🔍"
  },
  {
    title: "Email Integration",
    description: "Automated email sequences that nurture leads into paying customers.",
    icon: "✉️"
  },
  {
    title: "Performance Tracking",
    description: "Real-time analytics to measure what's working and optimize accordingly.",
    icon: "📊"
  }
]
</script>

<template>
  <section class="section features">
    <div class="container">
      <h2 class="section-title">Our Funnel Superpowers</h2>
      <p class="section-subtitle">We combine cutting-edge technology with proven marketing strategies to create funnels that convert.</p>
      
      <div class="features-grid">
        <div v-for="(feature, index) in features" :key="index" class="feature-card">
          <div class="feature-icon">{{ feature.icon }}</div>
          <h3>{{ feature.title }}</h3>
          <p>{{ feature.description }}</p>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.features {
  background: linear-gradient(to bottom, var(--darker), var(--dark));
}

.features-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 30px;
}

.feature-card {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(255, 255, 255, 0.1);
  border-radius: 15px;
  padding: 30px;
  transition: all 0.3s ease;
  backdrop-filter: blur(5px);
}

.feature-card:hover {
  transform: translateY(-10px);
  box-shadow: 0 10px 30px rgba(108, 71, 255, 0.2);
  border-color: rgba(108, 71, 255, 0.3);
}

.feature-icon {
  font-size: 2.5rem;
  margin-bottom: 20px;
}

.feature-card h3 {
  font-size: 1.3rem;
  margin-bottom: 15px;
  color: white;
}

.feature-card p {
  color: rgba(255, 255, 255, 0.7);
  line-height: 1.6;
}
</style>
