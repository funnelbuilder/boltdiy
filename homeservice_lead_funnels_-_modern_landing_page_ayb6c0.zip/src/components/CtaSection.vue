<script setup lang="ts">
import { ref } from 'vue'

const name = ref('')
const email = ref('')
const phone = ref('')
const submitted = ref(false)

const submitForm = () => {
  // In a real app, you would send this data to your backend
  console.log('Form submitted:', { name: name.value, email: email.value, phone: phone.value })
  submitted.value = true
  name.value = ''
  email.value = ''
  phone.value = ''
}
</script>

<template>
  <section id="cta" class="section cta">
    <div class="glow glow-primary" style="top: 50%; left: 50%; transform: translate(-50%, -50%);"></div>
    
    <div class="container">
      <div class="cta-content">
        <h2 class="section-title">Ready to Get More Leads?</h2>
        <p class="section-subtitle">Book a free strategy call with our funnel experts. We'll analyze your business and create a custom plan to grow your leads.</p>
        
        <div v-if="!submitted" class="cta-form">
          <div class="form-group">
            <input v-model="name" type="text" placeholder="Your Name" required>
          </div>
          <div class="form-group">
            <input v-model="email" type="email" placeholder="Your Email" required>
          </div>
          <div class="form-group">
            <input v-model="phone" type="tel" placeholder="Your Phone Number">
          </div>
          <button @click="submitForm" class="btn btn-primary">Schedule My Free Call</button>
        </div>
        
        <div v-else class="success-message">
          <h3>Thank You!</h3>
          <p>We've received your request and will contact you shortly to schedule your free strategy call.</p>
        </div>
      </div>
    </div>
  </section>
</template>

<style scoped>
.cta {
  background: linear-gradient(135deg, var(--darker), var(--dark));
  text-align: center;
  position: relative;
  overflow: hidden;
}

.cta-content {
  max-width: 600px;
  margin: 0 auto;
  position: relative;
  z-index: 2;
}

.cta-form {
  display: grid;
  gap: 20px;
  margin-top: 40px;
}

.form-group input {
  width: 100%;
  padding: 15px 20px;
  border-radius: 50px;
  border: none;
  background: rgba(255, 255, 255, 0.1);
  color: white;
  font-size: 1rem;
  transition: all 0.3s ease;
}

.form-group input:focus {
  outline: none;
  background: rgba(255, 255, 255, 0.2);
  box-shadow: 0 0 0 2px var(--primary);
}

.success-message {
  background: rgba(255, 255, 255, 0.05);
  border: 1px solid rgba(108, 71, 255, 0.3);
  border-radius: 15px;
  padding: 40px;
  margin-top: 40px;
}

.success-message h3 {
  font-size: 1.8rem;
  margin-bottom: 20px;
  color: var(--primary);
}

.success-message p {
  color: rgba(255, 255, 255, 0.8);
  line-height: 1.6;
}
</style>
